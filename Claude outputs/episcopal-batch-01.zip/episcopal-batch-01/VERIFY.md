# One-time verification (only the chat whose ASSIGNMENT.md says so)

Goal: confirm that all current data for all current parishes, and the diocesan boundaries, are correct BEFORE collecting new dioceses. Report only — change nothing in the repo without the user's OK.

## A. Automated checks (in your clone of the repo)
1. `python3 tools/normalize_data.py --check` (expect "0 change(s) pending"; list its "check by hand" items).
2. `python3 tools/build_parishes.py --check` (parishes.json up to date).
3. `python3 tools/import_parishes.py --sort-only --dry-run` (schema: keys, order, types).
4. `mkdir -p data/wip-dioceses && cd tools/diocese-boundaries && npm ci && npm run check` (overlaps, gaps, enclaves, pins in the wrong diocese). Known before this run: 9 "[stale] parish exception no longer needed" entries in parish-exceptions.json.
5. A short python audit over data/states/*/*.json, reporting counts and examples of: keys not exactly the 40 in data/schema.json order; values not allowed by schema list_options (choice / "; "-joined choices); duplicate ids; missing lat/lon; addresses without a 5-digit ZIP or street number; placeholder addresses; record "state" not matching its folder; more than one diocesan_bishop value per diocese; date_last_updated or verification_status blank/odd; notes starting "FLAG" or "POSSIBLY CLOSED/MERGED".

## B. Browser checks (Claude in Chrome, same rules as RULES.md; one tab per subagent)
1. Bishops: for each of the 21 done dioceses, read the diocese's own site and confirm the current diocesan bishop (styled name; female or not by title/pronoun; provisional/assisting/vacant). Report any mismatch with the data.
2. Diocese list: compare tools/diocese-boundaries/dioceses.json with the Episcopal Asset Map's list of dioceses (episcopalassetmap.org/dioceses). Report mergers, renames, or missing/extra dioceses.
3. Flagged parishes: re-check every record whose notes start "FLAG" or "POSSIBLY CLOSED/MERGED" (Asset Map, diocese site, parish site/Facebook, Google Maps for pins). All 4 records without map pins (1,653 parishes vs 1,649 pins) are among these. Known open cases: St. Stephen's (Batesville, MS) address; Church of the Annunciation (Perkinston, MS) still worshipping?; All Saints' (Inverness, MS) address; Church of the Common Ground (Atlanta, GA) pin; Christ the King (Lilburn, GA) likely closed; St. Paul's (Woodlawn, TX) pin.
4. Spot check: 2 random non-flagged parishes per done diocese (42 total) — compare address, phone, clergy, Sunday times with the parish's own site.

## C. Report
Write VERIFY-REPORT.md: one section per check, each issue with file, parish id, current value, correct value, source URL, and proposed fix. Deliver it with SendUserFile, post a 5-line summary, then continue with your diocese assignment. Apply fixes only after the user approves them.
