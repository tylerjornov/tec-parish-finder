# Assignment — batch 1 of 29

1. FIRST, this run only: do the one-time verification in VERIFY.md and deliver VERIFY-REPORT.md.
2. Collect, in this order: Maryland → Northwestern Pennsylvania → Pittsburgh. Deliver each diocese's file(s) and checkpoint as soon as that diocese is finished.
3. When all of them are delivered, stop. Do not start any other diocese.

Every other incomplete diocese belongs to another batch running in its own chat. Collect only the dioceses above.
