# Assignment — chat 2 of 3 (runs alongside two other chats)
1. Collect: Pennsylvania → Albany. Add Central New York only if BOTH have fewer than 60 parishes.
2. Pause after that and deliver the files. Do not continue without the user's OK.
Other chats have: Maryland, Northwestern Pennsylvania, Pittsburgh, plus a one-time data verification (chat 1); Long Island, New York, Rochester (chat 3). Never touch those. Do not run VERIFY-style checks of existing data; chat 1 does that.
