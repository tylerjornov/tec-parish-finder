# Handoff — Episcopal parish JSON collection

## Your assignment
See ASSIGNMENT.md (it differs per chat; other chats are working on other dioceses at the same time — never touch dioceses outside your assignment).

## Status
- Repo (public, the source of truth): https://github.com/tylerjornov/tec-parish-finder. Parish data lives in data/states/<state>/<diocese>.json; data/parishes.json is generated from those files; data/schema.json defines the 40 fields, their order and allowed values.
- DONE (21 dioceses, 1,653 parishes): Alabama, Atlanta, Central Gulf Coast, Dallas, East Carolina, East Tennessee, Easton, Georgia, Mississippi, North Carolina, South Carolina, Southern Virginia, Southwestern Virginia, Susquehanna, Tennessee, Texas, Upper South Carolina, Virginia, Washington (MD + DC), West Tennessee, Western North Carolina.
- Note: Bethlehem and Central Pennsylvania (formerly Harrisburg) no longer exist separately — they are the Diocese of the Susquehanna (done). Northwestern Pennsylvania is still separate. If you find any other diocese has merged or been renamed, say so before collecting it.

## Incomplete dioceses (75) — work order
Priority order: Maryland, Northwestern Pennsylvania, Pennsylvania, Pittsburgh, Albany, Central New York, Long Island, New York, Rochester, Western New York, Central Florida, Florida, Southeast Florida, Southwest Florida, Hawaiʻi, Rio Grande (far West Texas parishes go in the texas folder).
Then, alphabetically: Alaska, Arizona, Arkansas, California, Chicago, Colorado, Connecticut, Delaware, Eastern Oregon, El Camino Real, Great Lakes, Idaho, Indianapolis, Iowa, Kansas, Kentucky, Lexington, Los Angeles, Louisiana, Maine, Massachusetts, Michigan, Minnesota, Missouri, Montana, Navajoland, Nebraska, Nevada, New Hampshire, New Jersey, Newark, North Dakota, Northern California, Northern Indiana, Northern Michigan, Northwest Texas, Ohio, Oklahoma, Olympia, Oregon, Puerto Rico, Rhode Island, San Diego, San Joaquin, South Dakota, Southern Ohio, Spokane, Springfield, Utah, Vermont, Virgin Islands, West Missouri, West Texas, West Virginia, Western Kansas, Western Louisiana, Western Massachusetts, Wisconsin, Wyoming.
(Computed from tools/diocese-boundaries/dioceses.json minus the done list.)

## Setup (a new session starts empty)
Copy these files to /home/claude/work/ (the md files refer to that path). Run the python scripts with `python3 -I` from that folder. `git clone https://github.com/tylerjornov/tec-parish-finder` into a separate folder for the repo tools and checks. Create one Chrome tab per worker (tabs_create_mcp) and pass each worker its own tab id; re-check tab ids with tabs_context_mcp between turns.

## Pipeline that worked
1. Lister subagent (LIST.md) per diocese → <diocese>/list.json (Asset Map list pages + diocesan directory + bishop, gender of bishop). Two listers can run in parallel on separate tabs.
2. python3 -I split.py <dir> N → in_1..N.json (~11–13 each).
3. One worker subagent per slice (WORKER.md → COMBINED.md → RULES.md/STEP1/STEP2), each with its OWN Chrome tab id, up to 4 in parallel (other chats share the browser), sonnet, in waves. Tell each worker: the diocese, the diocesan_bishop string, the Asset Map slug, the diocese site, today's date for date_last_updated, its in_N.json and rec_N.json paths, and "Reply ONLY done N/M + <=3 flag lines".
4. python3 -I finalize.py <dir> <dir>/final.json [--female-bishop] → key order, ids, phones, choice values, rite values, URL slashes, women's-ordination consistency, date. --female-bishop (only when the diocesan bishop is a woman) adds "Yes - Diocesan Bishop" and sets womens_ordination_affirmed to "Yes - Episcopacy, Priesthood, & Diaconate" for every record.
5. Review flags (grep notes for "POSSIBLY CLOSED/MERGED", "blocked", "FLAG"). Drop congregations confirmed closed/merged by an allowed source; keep unconfirmed ones with notes starting "FLAG: manual check needed." Tell the user each drop.
6. Repo format: copy final.json into the clone as data/states/<state-folder>/<diocese>.json. State folder = full state name, lowercase, hyphenated ("new-york", "district-of-columbia"); file = diocese name, lowercase, hyphenated ("northwestern-pennsylvania"). A diocese spanning states gets one file per state folder (split by each record's "state").
7. In the clone: `python3 tools/normalize_data.py <your files>`, `python3 tools/build_parishes.py`, `python3 tools/import_parishes.py --sort-only --dry-run` (schema check), and `mkdir -p data/wip-dioceses && cd tools/diocese-boundaries && npm ci && npm run check` (pins in the right diocese). Fix anything they report about your files. Do not push to GitHub.
8. Deliver the normalized diocese file(s) with SendUserFile (repo path in the caption), plus the checkpoint JSON and "[X] parishes collected, [Y] flagged." (flagged = notes start "FLAG" or contain "blocked: manual check").

## User preferences
- Deliver each diocese as a FILE; post the checkpoint block + closing line in chat. Be brief and direct.
- Browser: Claude in Chrome only, operate like a human (navigate/get_page_text/find/click). NO javascript_tool, no scripts against websites, read-only.
- Stop exactly when told; do not start the next diocese without permission. "Ready" must mean records are built.
- Prompts meant to be pasted elsewhere go in a markdown code block.

## Gotchas
- Asset Map detail URLs: /dioceses/<slug>/list/<page-slug> or /dioceses/diocese-<slug>/list/<page-slug>; slugs are unpredictable and duplicate names get -0/-1/-2 suffixes (a wrong slug often shows another parish: always confirm the address). Map keyword search + pin popup + find "More Details" href works. lat/lon from the "Get directions" href (daddr=LAT,LON).
- Asset Map list pages are 0-indexed (?page=0).
- Many dioceses' "Find a Church" is an embedded Asset Map (no separate directory); workers then fill zip/phone/clergy from detail pages and parish sites.
- Diocesan subdomains for parish sites often redirect to the diocese home or fail: use the parish's real domain or Facebook, else the Asset Map URL, and note it. Some old domains are hijacked/spam: don't visit; find the real site by Google.
- Gender only from title/pronoun on allowed sources (Asset Map, diocese site, parish site/Facebook). Never external bios/news/Google snippets. Many records end up female_clergy N/A; that is expected.
- Shared-address entries (parish + campus ministry) and two Asset Map listings for one bilingual parish: one record per worshipping congregation; note the merge.
- No WebFetch/curl against parish sites; Chrome only. (git clone and npm against GitHub/npm are fine.)
