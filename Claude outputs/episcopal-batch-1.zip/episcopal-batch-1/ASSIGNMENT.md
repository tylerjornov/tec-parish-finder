# Assignment — chat 1 of 3 (runs alongside two other chats)
1. FIRST, this run only: do the one-time verification in VERIFY.md and deliver VERIFY-REPORT.md.
2. Then collect: Maryland → Northwestern Pennsylvania. Add Pittsburgh only if BOTH have fewer than 60 parishes.
3. Pause after that and deliver the files. Do not continue without the user's OK.
Other chats have: Pennsylvania, Albany, Central New York (chat 2); Long Island, New York, Rochester (chat 3). Never touch those.
