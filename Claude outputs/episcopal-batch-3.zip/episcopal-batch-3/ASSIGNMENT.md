# Assignment — chat 3 of 3 (runs alongside two other chats)
1. Collect: Long Island → New York. Add Rochester only if BOTH have fewer than 60 parishes.
2. Pause after that and deliver the files. Do not continue without the user's OK.
Other chats have: Maryland, Northwestern Pennsylvania, Pittsburgh, plus a one-time data verification (chat 1); Pennsylvania, Albany, Central New York (chat 2). Never touch those. Do not run VERIFY-style checks of existing data; chat 1 does that.
