# Assignment — batch 29 of 29

1. Collect, in this order: Hawaiʻi → Rio Grande → Navajoland → Utah. Deliver each diocese's file(s) and checkpoint as soon as that diocese is finished.
2. When all of them are delivered, stop. Do not start any other diocese.

Notes:
- Rio Grande spans New Mexico and far West Texas: new-mexico/rio-grande.json and texas/rio-grande.json.
- Navajoland spans Arizona, New Mexico and Utah: one file per state folder.

Every other incomplete diocese belongs to another batch running in its own chat. Collect only the dioceses above. Do not run checks of existing data; batch 1 does that.
