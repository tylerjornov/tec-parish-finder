# Assignment — batch 17 of 29

1. Collect, in this order: Indianapolis → Northern Indiana → Wisconsin. Deliver each diocese's file(s) and checkpoint as soon as that diocese is finished.
2. When all of them are delivered, stop. Do not start any other diocese.

Every other incomplete diocese belongs to another batch running in its own chat. Collect only the dioceses above. Do not run checks of existing data; batch 1 does that.
