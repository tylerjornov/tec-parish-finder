# Episcopal parish data collection — rules for agents

## Browser rules (STRICT)
- Use ONLY the Claude-in-Chrome browser tools, and ONLY the tab id you were assigned. Never open/close other tabs.
- Operate like a human: navigate, get_page_text, find, click, screenshot. Do NOT use javascript_tool. Do NOT run scripts against websites. Do not use curl/WebFetch.
- Read-only: never submit forms, sign in, create accounts, send messages, download files, post, like, or comment. Facebook/YouTube are read-only. Decline non-essential cookies if a banner blocks content.
- Visit only: episcopalassetmap.org, the diocese's site, the parish's own site (incl. its Facebook page), Google search (to find an official parish site), Google Maps (to confirm coordinates).
- If a domain is dead/parked/hijacked/spam, do not interact; search Google for the real site and note the change.
- If a page is blocked, set notes to "blocked: manual check needed".
- Prefer get_page_text (cheap). Use `find` to read link hrefs (e.g. Asset Map "Get directions" href contains lat,lon). Use browser_batch to chain steps.
- Be token-efficient: typically check the home page plus at most 2-3 subpages (About/Staff/Clergy, Worship/Services/Visit). Don't screenshot unless needed.

## Never invent or guess data. A blank field is better than a wrong one.

## Record schema — exactly these 40 keys, in this order
id, name, website, address, state, diocese, churchmanship, female_clergy, womens_ordination_affirmed, lgbt_clergy, lgbt_ordination_affirmed, ssm, theological_cultural_alignment, other_contact, verification_status, lat, lon, asa, city, church_phone, church_email, rector_phone, rector_email, sunday_services, weekday_services, diocesan_bishop, clergy_title, rector_name, other_clergy, rite, celebrant_position, service_languages, livestream_url, music_style, accessibility, parking, childcare, formation, date_last_updated, notes
(This order matches data/schema.json in the repo github.com/tylerjornov/tec-parish-finder. There is no rite_details field any more.)

## Field rules
- id: slug of name + street + city + state. Lowercase, accents stripped, apostrophes and periods removed, other non-alphanumerics become hyphens (collapse repeats, trim). e.g. "St. Mark's Episcopal Church","131 Hill St","Copperhill","TN" -> "st-marks-episcopal-church-131-hill-st-copperhill-tn". (The orchestrator will regenerate ids; just get name/address right.)
- address: "Street, City, ST ZIP" (e.g. "200 Church St, Abbeville, SC 29620"). Use 5-digit ZIP.
- website: parish's own site. If only Facebook, the Facebook page. If neither, the Asset Map listing URL. A bare domain has no trailing slash ("https://x.org", not "https://x.org/").
- state: two-letter state of street address. diocese: diocese name only (e.g. "East Tennessee").
- diocesan_bishop: given to you by the orchestrator.
- lat/lon: numbers (5 decimals) from Asset Map "Get directions" href or exact address pin. asa: null unless published.
- clergy_title: "" for a Rector (or Dean of a cathedral). Otherwise the title, e.g. "Vicar", "Priest-in-Charge", "Interim Rector", "Supply Priest". If no clergy known, "".
- rector_name: "The Rev. First Last" (keep "Dr." if site uses "The Rev. Dr."), or "Fr. First Last"/"Mtr. First Last" if the site uses that style. "The Rt. Rev." for a bishop. "The Very Rev." only if the official site uses it.
- other_clergy: "; "-separated "The Rev. Name (Title)" for other priests/deacons.
- Phones: (###) ###-####. If other_contact starts with a phone, same format.
- Empty: "" for text, null for numbers, "N/A - Data Not Available" for choice fields.
- verification_status: "Unverified". date_last_updated: today's date (YYYY-MM-DD), given to you by the orchestrator.
- rite: one or more of "Rite I", "Rite II", "1928 Book of Common Prayer", "Other", joined with "; " in that order (e.g. "Rite I; Rite II"); "" if the parish does not say. Which service uses which rite goes in sunday_services (e.g. "8:00 AM Holy Eucharist, Rite I").
- celebrant_position: "Ad Orientem" and/or "Versus Populum" (joined with "; ") only if the parish states it; otherwise "".
- service_languages: "English" when English-only; "English; Spanish" etc.
- times with AM/PM; ranges use a plain hyphen with no spaces ("9:15-11:45 AM", "Mon-Fri", "Sept-May"), e.g. "8:00 AM Holy Eucharist, Rite I; 10:30 AM Holy Eucharist, Rite II". If only a time is published, "Sunday worship".
- weekday_services: weekday and Saturday services, e.g. "Wed 12:00 PM Holy Eucharist with Healing". Bible studies/groups go in formation.
- livestream_url: YouTube/Facebook live/stream page if published.
- music_style, accessibility, parking, childcare, formation: short factual phrases from the site, else "".
- notes: doubts, conflicts, "Mission congregation" for missions, stale site warnings, domain changes, Asset Map vs site conflicts.

## Choice fields (exact values only)
- churchmanship: Anglo-Papalist | Anglo-Catholic | Prayer Book Catholic | Old High Church | Broad Church | Old Low Church | Evangelical | Charismatic | N/A - Data Not Available
- female_clergy: Yes - Diocesan Bishop | Yes - Rector | Yes - Other Priest | Yes - Deacon | No - None of the Clergy Here Are Female | N/A - Data Not Available  (join multiple with "; ")
- womens_ordination_affirmed: Yes - Episcopacy, Priesthood, & Diaconate | Yes - Priesthood & Diaconate | Yes - Diaconate Only | No - Female Clergy Not Accepted | N/A - Data Not Available
- lgbt_clergy: Yes - Diocesan Bishop | Yes - Rector | Yes - Other Priest | Yes - Deacon | No - None of the Clergy Here Are LGBT | N/A - Data Not Available
- lgbt_ordination_affirmed: Yes - Episcopacy, Priesthood, & Diaconate | Yes - Priesthood & Diaconate | Yes - Diaconate Only | No - LGBT Clergy Not Accepted | N/A - Data Not Available
- ssm: Yes - Practiced | Yes - Affirmed but not Practiced | No - Alternative Blessings Practiced | No - Homosexuality Seen as Sinful | N/A - Data Not Available
- theological_cultural_alignment: Inclusive Orthodox - Socially Progressive & Theologically Conservative | Traditional Orthodox - Both Theologically & Socially Conservative | Moderate Liberal - Theologically & Socially Progressive, fully affirms the three creeds | Progressive - Theologically & Socially Progressive, rejects some aspect of three creeds | N/A - Data Not Available

## Conventions
- female_clergy: "Yes - Rector" if the rector/vicar/priest-in-charge (the lead clergy) is female; "Yes - Other Priest" for other female priests; "Yes - Deacon" for female deacons. Use "No - ..." only when the full published clergy roster is male by title or pronoun. A female title ("Mother"/"Mtr.") or feminine pronoun (incl. bio pages) counts as Yes. NEVER infer gender from a name alone — if gender cannot be confirmed from title/pronoun, use N/A.
- womens_ordination_affirmed: "Yes - Priesthood & Diaconate" when a woman priest serves and the bishop is male; "Yes - Diaconate Only" when only women deacons are confirmed; otherwise N/A.
- lgbt_clergy: only "Yes - ..." if the site states it (e.g. a priest's bio mentions husband/wife of same sex). Otherwise N/A. Never "No".
- churchmanship and other opinion fields (lgbt_ordination_affirmed, ssm, theological_cultural_alignment): N/A unless the parish states its position. A weekly rosary alone, or "Mass" plus kneeling alone, is not enough. ssm "Yes - Practiced" only if the site says it performs same-sex weddings. A generic "all are welcome" or "LGBTQ+ welcome" statement alone does not set ssm/alignment.
- Spanish-language or other-language congregations sharing a building get their own record.
- If the parish site's city/zip conflicts with Asset Map/diocese, use the parish site and note the conflict.
- rector_email only when the site publishes it for that person. rector_phone likewise.
- If Asset Map and parish site disagree on clergy, use the parish site. If the site looks stale, say so in notes.
- Exclude closed/merged congregations, schools, camps, foundations, offices unless they hold regular public worship. Chapels inside a parish are not separate entries.

## Source discipline (added)
- Facts (clergy names, gender, services, positions) must come from the Asset Map, the diocese's own site, or the parish's own site/Facebook/YouTube. Do NOT use news sites, other churches' sites, LinkedIn, obituaries, seminary bios, or Google snippets as evidence. Google is only for finding the official site.
- A congregation not on the diocesan directory, whose diocese announced a final service / closure / sale, should still be written but with notes starting "POSSIBLY CLOSED/MERGED:" — the orchestrator decides.
