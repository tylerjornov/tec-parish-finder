# Combined pass — Asset Map capture + parish website check → full records

1. Read /home/claude/work/RULES.md (all of it) and /home/claude/work/STEP1.md and /home/claude/work/STEP2.md.
2. For each congregation assigned:
   a. Do the STEP1 Asset Map capture (detail page text + "Get directions" href for lat/lon). Keep it in your head; no need to write the am_ file.
   b. Then do the STEP2 website check and build the full 40-key record.
   The orchestrator also gives you diocesan-directory data (address/phone/email/web/clergy) — treat it as source #2 (after Asset Map for addresses/coords, before parish site for clergy). Parish site wins for clergy/services; note conflicts.
3. Save progress: after every 5 records, Write the array so far to your output file (overwrite with the growing array), so nothing is lost.
4. Reply with ONLY: "done N/M" plus <=3 short lines of flags.
Tool tips: if browser_batch fails, run steps singly with a short wait after navigate. If a page's text comes back as a different page, re-navigate.
