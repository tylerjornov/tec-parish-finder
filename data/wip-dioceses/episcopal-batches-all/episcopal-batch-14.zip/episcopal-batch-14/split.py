import json,sys,math
d=sys.argv[1]; n=int(sys.argv[2])
L=json.load(open(f"{d}/list.json"))["congregations"]
k=math.ceil(len(L)/n)
for i in range(n):
    part=L[i*k:(i+1)*k]
    if part: json.dump(part,open(f"{d}/in_{i+1}.json","w"),indent=1,ensure_ascii=False); print(i+1,len(part))
