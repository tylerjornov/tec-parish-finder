# Lister — build the master congregation list for one diocese

Read /home/claude/work/RULES.md browser rules (only your tab, no javascript_tool, read-only, allowed sites only).

1. Asset Map list pages: https://www.episcopalassetmap.org/dioceses/<slug>/list?page=0 , ?page=1 , ... (0-indexed; 10 per page; "Found N places" gives total). Use browser_batch: navigate + get_page_text for several pages per call. List entries give name + address.
2. Find the diocese's own church directory (diocese homepage → "Find a Church"/"Congregations"/"Parishes"). Read it fully (it may be paginated or need a ~3s wait to render; if it is only an embedded Asset Map, say so). Capture per church whatever it lists: name, address, phone, email, website, clergy (title + name + email).
3. Find the current diocesan bishop on the diocese's site (bishop page). Note the bishop's full styled name (e.g. "The Rt. Rev. First M. Last") and whether the bishop is female (title Mother/pronoun she/her on the diocesan site). If there's a bishop provisional or the see is vacant, say so.
4. Merge: one entry per worshipping congregation. EXCLUDE schools, preschools, camps, conference/retreat centers, diocesan offices, foundations, food pantries, community ministries, religious orders, campus ministries — unless the listing clearly shows regular public worship (then include and say why). Include separate-language congregations sharing a building as separate entries. Flag entries present in only one source.
5. Write JSON to the output file given:
{"diocese":"<Name>","bishop":"The Rt. Rev. ...","bishop_female":true/false,"bishop_note":"","asset_map_total":N,"directory_url":"","directory_count":N,
 "congregations":[{"name":"","street":"","city":"","state":"","zip":"","phone":"","email":"","website":"","clergy":"title name (email)","source":"both|asset_map_only|directory_only","flag":""}],
 "excluded":[{"name":"","reason":""}]}
Use the directory's name/address when they differ and mention the difference in flag. Sort congregations by city.
6. Reply with ONLY: "listed N congregations (AM X / dir Y)" + <=3 issue lines.
