import json,glob,re,sys,unicodedata,datetime
KEYS="id, name, website, address, state, diocese, churchmanship, female_clergy, womens_ordination_affirmed, lgbt_clergy, lgbt_ordination_affirmed, ssm, theological_cultural_alignment, other_contact, verification_status, lat, lon, asa, city, church_phone, church_email, rector_phone, rector_email, sunday_services, weekday_services, diocesan_bishop, clergy_title, rector_name, other_clergy, rite, celebrant_position, service_languages, livestream_url, music_style, accessibility, parking, childcare, formation, date_last_updated, notes".split(", ")
NA="N/A - Data Not Available"
CH={
"churchmanship":["Anglo-Papalist","Anglo-Catholic","Prayer Book Catholic","Old High Church","Broad Church","Old Low Church","Evangelical","Charismatic",NA],
"female_clergy":["Yes - Diocesan Bishop","Yes - Rector","Yes - Other Priest","Yes - Deacon","No - None of the Clergy Here Are Female",NA],
"lgbt_clergy":["Yes - Diocesan Bishop","Yes - Rector","Yes - Other Priest","Yes - Deacon","No - None of the Clergy Here Are LGBT",NA],
"womens_ordination_affirmed":["Yes - Episcopacy, Priesthood, & Diaconate","Yes - Priesthood & Diaconate","Yes - Diaconate Only","No - Female Clergy Not Accepted",NA],
"lgbt_ordination_affirmed":["Yes - Episcopacy, Priesthood, & Diaconate","Yes - Priesthood & Diaconate","Yes - Diaconate Only","No - LGBT Clergy Not Accepted",NA],
"ssm":["Yes - Practiced","Yes - Affirmed but not Practiced","No - Alternative Blessings Practiced","No - Homosexuality Seen as Sinful",NA],
"theological_cultural_alignment":["Inclusive Orthodox - Socially Progressive & Theologically Conservative","Traditional Orthodox - Both Theologically & Socially Conservative","Moderate Liberal - Theologically & Socially Progressive, fully affirms the three creeds","Progressive - Theologically & Socially Progressive, rejects some aspect of three creeds",NA]}
MULTI={"female_clergy","lgbt_clergy"}
def slug(s):
    s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower()
    s=re.sub(r"['’.]","",s); s=re.sub(r"[^a-z0-9]+","-",s); return s.strip('-')
def phone(p):
    if not p: return ""
    d=re.sub(r"\D","",p)
    if len(d)==11 and d[0]=='1': d=d[1:]
    if len(d)==10: return f"({d[:3]}) {d[3:6]}-{d[6:]}"
    return p
FEMALE_BISHOP=False
def fix(r,warn):
    o={}
    for k in KEYS: o[k]=r.get(k, None)
    extra=set(r)-set(KEYS)-{"rite_details"}
    if extra: warn.append(f"{r.get('name')}: extra keys {extra}")
    for k in KEYS:
        if o[k] is None and k not in ("lat","lon","asa"): o[k]= NA if k in CH else ""
    for k,vals in CH.items():
        v=o[k] or NA
        parts=[x.strip() for x in v.split(";")] if k in MULTI else [v]
        for x in parts:
            if x not in vals: warn.append(f"{o['name']}: bad {k}={v!r}"); 
        o[k]=v
    for k in ("church_phone","rector_phone"): o[k]=phone(o[k])
    oc=o["other_contact"] or ""
    m=re.match(r"^\s*(\+?1?[\s.-]*\(?\d{3}\)?[\s.-]*\d{3}[\s.-]*\d{4})(.*)$",oc)
    if m: o["other_contact"]=phone(m.group(1))+m.group(2)
    legacy={"I":"Rite I","II":"Rite II","Mixed":"Rite I; Rite II"}
    if o["rite"] in legacy: o["rite"]=legacy[o["rite"]]
    RITES=["Rite I","Rite II","1928 Book of Common Prayer","Other"]
    rp=[x.strip() for x in o["rite"].split(";") if x.strip()]
    if any(x not in RITES for x in rp): warn.append(f"{o['name']}: bad rite {o['rite']!r}")
    else: o["rite"]="; ".join(sorted(rp,key=RITES.index))
    if o["celebrant_position"] and any(x.strip() not in ("Ad Orientem","Versus Populum") for x in o["celebrant_position"].split(";")): warn.append(f"{o['name']}: bad celebrant_position {o['celebrant_position']!r}")
    for k in ("website","livestream_url"):
        v=(o[k] or "").strip()
        if re.fullmatch(r"https?://[^/?#\s]+/", v, re.I): o[k]=v[:-1]
    o["verification_status"]="Unverified"; o["date_last_updated"]=datetime.date.today().isoformat()
    for k in ("lat","lon"):
        if o[k] is not None:
            try: o[k]=round(float(o[k]),5)
            except: warn.append(f"{o['name']}: bad {k}"); o[k]=None
    if o["asa"] in ("",): o["asa"]=None
    street=o["address"].split(",")[0] if o["address"] else ""
    o["id"]=slug(f"{o['name']} {street} {o['city']} {o['state']}")
    fc=o["female_clergy"]; w=o["womens_ordination_affirmed"]
    if ("Rector" in fc or "Other Priest" in fc) and w in (NA,"Yes - Diaconate Only"): o["womens_ordination_affirmed"]="Yes - Priesthood & Diaconate"
    elif fc=="Yes - Deacon" and w==NA: o["womens_ordination_affirmed"]="Yes - Diaconate Only"
    if FEMALE_BISHOP:
        fc=o["female_clergy"]
        if fc==NA or fc.startswith("No"): o["female_clergy"]="Yes - Diocesan Bishop"
        elif "Diocesan Bishop" not in fc: o["female_clergy"]="Yes - Diocesan Bishop; "+fc
        o["womens_ordination_affirmed"]="Yes - Episcopacy, Priesthood, & Diaconate"
    if not o["clergy_title"] is None and o["clergy_title"].lower() in ("rector","dean"): o["clergy_title"]=""
    return o
if __name__=="__main__":
    d=sys.argv[1]; out=sys.argv[2]
    if "--female-bishop" in sys.argv: FEMALE_BISHOP=True
    recs=[]
    for f in sorted(glob.glob(f"{d}/rec_*.json")): recs+=json.load(open(f))
    warn=[]; recs=[fix(r,warn) for r in recs]
    recs.sort(key=lambda r:(r["city"],r["name"]))
    ids=[r["id"] for r in recs]
    for i in set(ids):
        if ids.count(i)>1: warn.append("dup id "+i)
    json.dump(recs,open(out,"w"),indent=2,ensure_ascii=False)
    print(len(recs),"records"); print("\n".join(warn))
