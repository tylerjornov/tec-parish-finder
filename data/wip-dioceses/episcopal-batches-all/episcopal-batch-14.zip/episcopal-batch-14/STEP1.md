# Step 1 — Asset Map listing capture

Read /home/claude/work/RULES.md browser rules first (only the browser tools, only your tab, no javascript_tool, read-only).

For each congregation assigned to you, open its Episcopal Asset Map detail page and capture data.
- Detail page URL pattern: https://www.episcopalassetmap.org/dioceses/diocese-<diocese-slug>/list/<slug>
  The slug is the name lowercased with stopwords like "of", "the", "a", "and" dropped and punctuation removed (e.g. "Church of the Good Shepherd" -> "church-good-shepherd"; duplicates get "-0", "-1"...; "St. Mark's Episcopal Church" -> "st-marks-episcopal-church"). Guess the slug; confirm the address on the page matches.
- If the guess fails, go to https://www.episcopalassetmap.org/dioceses/<diocese-slug>/map , zoom/click the pin to get a popup, then use `find` for the "More Details" link href. (The list page entries are not links.)
- On the detail page use get_page_text, then `find` "Get directions link href" — the href contains daddr=LAT,LON.

Capture per congregation (JSON object):
{"name": as on Asset Map, "am_url": detail URL, "street": "", "city": "", "state": "", "zip": "5-digit", "phone": "(###) ###-####", "email": "", "website": "", "worship_raw": "verbatim-ish worship times text (compact)", "contacts_raw": "clergy/staff contacts listed (compact)", "groups_raw": "organized groups list (compact)", "lat": number, "lon": number, "notes": "anything odd (e.g. looks like a school/campus ministry with no worship, missing page)"}

Write the JSON array to the output file path you are given (use the Write tool). Then reply with ONLY one line: "done N/M" plus any problems in <=2 short lines.
