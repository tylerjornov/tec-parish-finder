# Step 2 — Parish website check & full record build

Read /home/claude/work/RULES.md completely first (browser rules, schema, field rules, conventions). Use ONLY your assigned Chrome tab; no javascript_tool; read-only.

Input: a JSON file of Asset Map captures (fields: name, am_url, street, city, state, zip, phone, email, website, worship_raw, contacts_raw, groups_raw, lat, lon, notes). Process the entries you are told to.

For each congregation:
1. Open its website (from the input; if blank or dead/parked/hijacked, Google "<name> <city> Episcopal" to find the official site or Facebook page; note any change). Read the home page, then at most ~3 key subpages (Staff/Clergy/About; Worship/Services/Visit/New here). If only Facebook, read the About/intro info that's visible without login.
2. Build the full 40-key record per RULES.md. Asset Map data is the baseline for address, phone, email, lat/lon, worship times; the parish site overrides for clergy, services, and contact details (note conflicts in notes). Note in notes if Asset Map and site disagree on times/name/address.
3. diocese and diocesan_bishop are given to you. verification_status "Unverified"; date_last_updated = today's date given to you by the orchestrator; asa null unless published.
4. Fill id as described in RULES (orchestrator will normalize).
5. If it's a mission (site/diocese says "mission"), put "Mission congregation" in notes.
6. If the congregation appears closed/merged/departed, still write the record but put "POSSIBLY CLOSED/MERGED:" + evidence at the start of notes.

Write the JSON array of complete records (all 40 keys, in order) to the output file you're given using the Write tool. Reply with ONLY: "done N/M" plus <=3 short lines of problems/flags.
