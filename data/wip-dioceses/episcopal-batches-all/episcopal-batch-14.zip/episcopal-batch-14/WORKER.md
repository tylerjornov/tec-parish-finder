# Worker — full records for a slice of congregations

Follow /home/claude/work/COMBINED.md (read it, RULES.md fully incl. "Source discipline", STEP1.md, STEP2.md).
Your input file is a JSON array of congregations compiled from the Asset Map list + diocesan directory (fields: name, street, city, state, zip, phone, email, website, clergy, source, flag). Treat its directory data as source #2.
For each: open the Asset Map detail page (lat/lon via "Get directions" href; worship times; contacts) — if the congregation is directory_only and not on the Asset Map, get lat/lon from a Google Maps pin of the exact address, or leave null — then the parish website, then build the 40-key record.
If the bishop is female, do NOT add "Yes - Diocesan Bishop" yourself — fill female_clergy from parish clergy only; the orchestrator adds the bishop.
Save progress to your output file after every 5 records. Reply ONLY "done N/M" + <=3 short lines of flags (closures/merges, dead sites, big conflicts).
Notes: never share scratch files with other workers — if you write helper scripts, name them with your output file stem (e.g. /tmp/claude-0/s/<diocese>_rec_3_build.py). Asset Map detail URLs are usually /dioceses/<slug>/list/<page-slug> (not always diocese-<slug>); slugs are unpredictable — the map keyword search (/dioceses/<slug>/map?keywords=<street>) then clicking the pin and `find` "More Details" href works.
